#ifndef _LISTES_H
#define _LISTES_H

struct cellule {
    char* command;
    struct cellule *suivant;
};
typedef struct cellule cellule_t;

struct liste {
    cellule_t *tete;
};

typedef struct liste liste_t;


#endif /* _LISTES_H */


