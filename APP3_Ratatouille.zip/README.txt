Bonjour,
On a finit l'acte 1 et l'acte 2. On a impletemente les fontions pour l'acte 3 a mais on etait coine la-dessous
comme on a eu un 'Segmentation fault (core dumped)' depuis ce weekend. On a essaye de rajouter des printfs un peu 
partout pour identifier la source de cette probleme.

Pour l'acte 2 et 3-a, toutes les entrees seront faites pendant l'execution de programme avec des scanfs.

